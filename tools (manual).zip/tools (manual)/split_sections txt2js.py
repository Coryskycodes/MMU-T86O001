import re
import json

input_path = #Insert TXT path
output_path = #Insert Output path
act_name = #Insert Act name

with open(input_path, "r", encoding="utf-8") as f:
    text = f.read()

# Split sections based on "Section X" pattern
pattern = r"(Section\s+\d+\.?.*?)\n"
sections = re.split(pattern, text)

data = []
current_section = None

for chunk in sections:
    if chunk.strip().startswith("Section"):
        # Save previous section
        if current_section:
            data.append(current_section)
        # Extract section number and title
        match = re.match(r"Section\s+(\d+)\.?\s*(.*)", chunk.strip())
        if match:
            sec_number = match.group(1)
            sec_title = match.group(2).strip() if match.group(2) else ""
            current_section = {
                "act": act_name,
                "section": sec_number,
                "title": sec_title,
                "text": ""
            }
    else:
        if current_section:
            current_section["text"] += chunk.strip() + " "

# Add last section
if current_section:
    data.append(current_section)

# Save to JSON
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f"Section splitting complete. Saved to: {output_path}")
print(f"Total sections found: {len(data)}")