import json
import os
import sys
from typing import Dict, List, Optional, Tuple
from datetime import datetime

# Import config for paths
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LAWS_FOLDER, LAWS_DELETED_FOLDER

from .validator import validate_law_file, validate_file_key, compare_versions
from .schema import create_law_schema

LAW_FOLDER = LAWS_FOLDER

def get_all_laws() -> List[Dict]:
    laws = []
    
    for filename in os.listdir(LAW_FOLDER):
        if filename.endswith('.json'):
            path = os.path.join(LAW_FOLDER, filename)
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict) and 'metadata' in data:
                        laws.append({
                            'filename': filename,
                            **data['metadata']
                        })
            except Exception as e:
                print(f"Error loading {filename}: {e}")
    
    return laws

def get_law_by_key(file_key: str) -> Optional[Dict]:
    filename = f"{file_key}.json"
    path = os.path.join(LAW_FOLDER, filename)
    
    if not os.path.exists(path):
        return None
    
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def add_law(data: Dict, overwrite: bool = False) -> Tuple[bool, str]:
    # Validate
    is_valid, errors = validate_law_file(data)
    if not is_valid:
        return (False, "Validation failed:\n" + "\n".join(errors))
    
    # Check file key
    file_key = data['metadata']['file_key']
    is_valid_key, key_error = validate_file_key(file_key)
    if not is_valid_key:
        return (False, f"Invalid file key: {key_error}")
    
    # Check if exists
    filename = f"{file_key}.json"
    path = os.path.join(LAW_FOLDER, filename)
    
    if os.path.exists(path) and not overwrite:
        return (False, f"Law '{file_key}' already exists. Use update instead.")
    
    # Save
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return (True, f"Successfully added law: {data['metadata']['act_name']}")
    except Exception as e:
        return (False, f"Error saving file: {str(e)}")

def update_law(file_key: str, new_data: Dict, check_version: bool = True) -> Tuple[bool, str, Optional[Dict]]:
    # Check if exists
    old_data = get_law_by_key(file_key)
    if old_data is None:
        return (False, f"Law '{file_key}' not found. Use add instead.", None)
    
    # Validate new data
    is_valid, errors = validate_law_file(new_data)
    if not is_valid:
        return (False, "Validation failed:\n" + "\n".join(errors), None)
    
    # Check file key matches
    if new_data['metadata']['file_key'] != file_key:
        return (False, f"File key mismatch: {new_data['metadata']['file_key']} != {file_key}", None)
    
    # Version check
    if check_version:
        old_version = old_data['metadata'].get('version', '0.0')
        new_version = new_data['metadata'].get('version', '0.0')
        
        try:
            old_v = float(old_version)
            new_v = float(new_version)
            if new_v <= old_v:
                return (False, f"New version ({new_version}) must be greater than old version ({old_version})", None)
        except:
            pass  # Skip version check if not numeric
    
    # Compare versions
    comparison = compare_versions(old_data, new_data)
    
    # Save
    filename = f"{file_key}.json"
    path = os.path.join(LAW_FOLDER, filename)
    
    try:
        # Backup old file
        backup_path = path.replace('.json', f'_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(old_data, f, indent=2, ensure_ascii=False)
        
        # Save new file
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(new_data, f, indent=2, ensure_ascii=False)
        
        return (True, f"Successfully updated law: {new_data['metadata']['act_name']}\nBackup saved to: {os.path.basename(backup_path)}", comparison)
    except Exception as e:
        return (False, f"Error saving file: {str(e)}", None)

def delete_law(file_key: str, create_backup: bool = True) -> Tuple[bool, str]:
    filename = f"{file_key}.json"
    path = os.path.join(LAW_FOLDER, filename)
    
    if not os.path.exists(path):
        return (False, f"Law '{file_key}' not found")
    
    try:
        # Create backup
        if create_backup:
            os.makedirs(LAWS_DELETED_FOLDER, exist_ok=True)
            
            backup_filename = f"{file_key}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            backup_path = os.path.join(LAWS_DELETED_FOLDER, backup_filename)
            
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            with open(backup_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        
        # Delete
        os.remove(path)
        
        msg = f"Successfully deleted law: {file_key}"
        if create_backup:
            msg += f"\nBackup saved to: laws_deleted/{backup_filename}"
        
        return (True, msg)
    except Exception as e:
        return (False, f"Error deleting file: {str(e)}")

def get_law_stats() -> Dict:
    laws = get_all_laws()
    
    total_sections = sum(law.get('total_sections', 0) for law in laws)
    
    # Group by year
    years = {}
    for law in laws:
        year = law.get('year', 'Unknown')
        years[year] = years.get(year, 0) + 1
    
    return {
        'total_laws': len(laws),
        'total_sections': total_sections,
        'laws_by_year': years,
        'oldest_year': min(years.keys()) if years else None,
        'newest_year': max(years.keys()) if years else None
    }