import json
import os
import re
import sys
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LAWS_FOLDER

from schema import create_law_schema, get_friendly_name

# Old to new filename
FILENAME_MAPPING = {
    "contracts_sections.json": "contracts_act_1950.json",
    "employment_section.json": "employment_act_1955.json",
    "company_section.json": "companies_act_2016.json",
    "national_land_code_section.json": "national_land_code_1965.json",
    "income_tax_section.json": "income_tax_act_1967.json",
    "civil_law_section.json": "civil_law_act_1956.json",
    "civil_law_section_emb.json": "civil_law_act_1956_embedded.json", 
    "ip_section.json": "ip_act_2002.json"
}

def extract_year_from_act_name(act_name: str) -> str:
    match = re.search(r'\b(19|20)\d{2}\b', act_name)
    return match.group(0) if match else "Unknown"

def detect_old_format(data) -> bool:
    return isinstance(data, list)

def migrate_law_file(old_path: str, new_path: str, new_filename: str):
    print(f"Migrating: {os.path.basename(old_path)} -> {new_filename}")
    
    # Read old file
    with open(old_path, 'r', encoding='utf-8') as f:
        old_data = json.load(f)
    
    if not detect_old_format(old_data):
        print(f"  File already in new format, skipping...")
        return
    
    # get the metadata
    if old_data and len(old_data) > 0:
        first_section = old_data[0]
        act_name = first_section.get('act', 'Unknown Act')
        year = extract_year_from_act_name(act_name)
    else:
        act_name = "Unknown Act"
        year = "Unknown"
    
    # Create file key
    file_key = new_filename.replace('.json', '')
    
    # get friendly name
    friendly_name = get_friendly_name(file_key)
    
    # for new format
    new_data = create_law_schema(
        act_name=friendly_name,
        file_key=file_key,
        year=year,
        sections=old_data,
        last_updated=datetime.now().strftime("%Y-%m-%d"),
        version="1.0",
        source="Migrated from legacy format"
    )
    
    # save em
    output_path = os.path.join(new_path, new_filename)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(new_data, f, indent=2, ensure_ascii=False)
    
    print(f" Migrated successfully!")
    print(f"     Act: {friendly_name}")
    print(f"     Year: {year}")
    print(f"     Sections: {len(old_data)}")

def migrate_all_laws(old_folder: str, new_folder: str):
    print("=" * 60)
    print("MALAYSIAN LAW DATABASE MIGRATION")
    print("=" * 60)
    print(f"From: {old_folder}")
    print(f"To:   {new_folder}")
    print()
    
    # if no folder the create one just in case
    os.makedirs(new_folder, exist_ok=True)
    
    # Get all json files
    json_files = [f for f in os.listdir(old_folder) if f.endswith('.json')]
    
    print(f"Found {len(json_files)} law files to migrate\n")
    
    migrated = 0
    skipped = 0
    
    for old_filename in json_files:
        old_path = os.path.join(old_folder, old_filename)
        
        new_filename = FILENAME_MAPPING.get(old_filename, old_filename)
        
        try:
            migrate_law_file(old_path, new_folder, new_filename)
            migrated += 1
        except Exception as e:
            print(f" Error migrating {old_filename}: {str(e)}")
            skipped += 1
        
        print()
    
    print("=" * 60)
    print(f"Migration Complete!")
    print(f"Migrated: {migrated}")
    print(f"Skipped:  {skipped}")
    print("=" * 60)

if __name__ == "__main__":
    OLD_LAWS_FOLDER = LAWS_FOLDER
    NEW_LAWS_FOLDER = os.path.join(os.path.dirname(LAWS_FOLDER), "laws_new")
    
    migrate_all_laws(OLD_LAWS_FOLDER, NEW_LAWS_FOLDER)
    
    print("\nNEXT STEPS:")
    print("1. Review the migrated files in 'laws_new' folder")
    print("2. If everything looks good, backup 'laws' folder")
    print("3. Replace 'laws' folder with 'laws_new'")
    print("4. Update your code to use new format")