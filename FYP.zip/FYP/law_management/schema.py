
from datetime import datetime
from typing import List, Dict, Optional

# version
SCHEMA_VERSION = "1.0"

def create_law_schema(
    act_name: str,
    file_key: str,
    year: str,
    sections: List[Dict],
    last_updated: Optional[str] = None,
    version: str = "1.0",
    source: str = "Official gazette"
) -> Dict:

    if last_updated is None:
        last_updated = datetime.now().strftime("%Y-%m-%d")
    
    return {
        "schema_version": SCHEMA_VERSION,
        "metadata": {
            "act_name": act_name,
            "file_key": file_key,
            "year": year,
            "last_updated": last_updated,
            "version": version,
            "total_sections": len(sections),
            "source": source
        },
        "sections": sections
    }

# the naming
FRIENDLY_NAME_MAPPING = {
    "contracts_act_1950": "Contracts Act 1950",
    "employment_act_1955": "Employment Act 1955",
    "companies_act_2016": "Companies Act 2016",
    "national_land_code_1965": "National Land Code 1965",
    "income_tax_act_1967": "Income Tax Act 1967",
    "civil_law_act_1956": "Civil Law Act 1956",
    "ip_act_2002": "Intellectual Property Corporation of Malaysia Act 2002"
}

# uno it for the mapping 
FILE_KEY_MAPPING = {v: k for k, v in FRIENDLY_NAME_MAPPING.items()}

def get_friendly_name(file_key: str) -> str:
    """Get human-readable name from file key"""
    return FRIENDLY_NAME_MAPPING.get(file_key, file_key.replace("_", " ").title())

def get_file_key(friendly_name: str) -> str:
    """Get file key from human-readable name"""
    return FILE_KEY_MAPPING.get(friendly_name, friendly_name.lower().replace(" ", "_"))