# this is for validating the file against the schema, hopefull it works

from typing import Dict, List, Tuple
from datetime import datetime

def validate_metadata(metadata: Dict) -> Tuple[bool, List[str]]:
    """
    Validate metadata structure
    
    Returns:
        (is_valid, list_of_errors)
    """
    errors = []
    required_fields = ['act_name', 'file_key', 'year', 'last_updated', 'version', 'total_sections', 'source']
    
    for field in required_fields:
        if field not in metadata:
            errors.append(f"Missing required field: {field}")
    
    # for data types
    if 'total_sections' in metadata and not isinstance(metadata['total_sections'], int):
        errors.append("total_sections must be an integer")
    
    # for the year format
    if 'year' in metadata:
        year = str(metadata['year'])
        if not year.isdigit() or len(year) != 4:
            errors.append(f"Invalid year format: {year} (should be YYYY)")
    
    # and lastly for date
    if 'last_updated' in metadata:
        try:
            datetime.fromisoformat(metadata['last_updated'])
        except:
            errors.append(f"Invalid date format: {metadata['last_updated']} (should be YYYY-MM-DD)")
    
    return (len(errors) == 0, errors)

def validate_section(section: Dict, section_num: int) -> Tuple[bool, List[str]]:
    """
    Validate a single section
    
    Returns:
        (is_valid, list_of_errors)
    """
    errors = []
    required_fields = ['section', 'title', 'text']
    
    for field in required_fields:
        if field not in section:
            errors.append(f"Section {section_num}: Missing required field '{field}'")
        elif not isinstance(section[field], str):
            errors.append(f"Section {section_num}: Field '{field}' must be a string")
    
    return (len(errors) == 0, errors)

def validate_law_file(data: Dict) -> Tuple[bool, List[str]]:
    """
    Validate entire law file structure
    
    Returns:
        (is_valid, list_of_errors)
    """
    errors = []
    
    # Check the top struc
    if not isinstance(data, dict):
        return (False, ["Law file must be a JSON object"])
    
    if 'metadata' not in data:
        errors.append("Missing 'metadata' field")
    
    if 'sections' not in data:
        errors.append("Missing 'sections' field")
    
    if errors:
        return (False, errors)
    
    # for the metadata
    # then for sections
    # make sure sec and meta match
    metadata_valid, metadata_errors = validate_metadata(data['metadata'])
    errors.extend(metadata_errors)
    
    if not isinstance(data['sections'], list):
        errors.append("'sections' must be an array")
    else:
        if len(data['sections']) == 0:
            errors.append("'sections' cannot be empty")
        

        for idx, section in enumerate(data['sections'], 1):
            section_valid, section_errors = validate_section(section, idx)
            errors.extend(section_errors)
        
        if 'metadata' in data and 'total_sections' in data['metadata']:
            if len(data['sections']) != data['metadata']['total_sections']:
                errors.append(f"Section count mismatch: metadata says {data['metadata']['total_sections']}, but found {len(data['sections'])}")
    
    return (len(errors) == 0, errors)

def validate_file_key(file_key: str) -> Tuple[bool, str]:
    """
    Validate file key format
    
    Returns:
        (is_valid, error_message)
    """
    # make sure they are lowercase
    if not file_key:
        return (False, "File key cannot be empty")
    
    if not file_key.replace('_', '').replace('0', '').replace('1', '').replace('2', '').replace('3', '').replace('4', '').replace('5', '').replace('6', '').replace('7', '').replace('8', '').replace('9', '').isalpha():
        return (False, "File key must contain only lowercase letters, numbers, and underscores")
    
    if file_key != file_key.lower():
        return (False, "File key must be lowercase")
    
    if file_key.startswith('_') or file_key.endswith('_'):
        return (False, "File key cannot start or end with underscore")
    
    if '__' in file_key:
        return (False, "File key cannot contain consecutive underscores")
    
    return (True, "")

def compare_versions(old_data: Dict, new_data: Dict) -> Dict:
    """
    Compare two versions of a law file
    
    Returns:
        Dictionary with comparison results
    """
    comparison = {
        "metadata_changes": {},
        "sections_added": 0,
        "sections_removed": 0,
        "sections_modified": 0,
        "total_old": len(old_data.get('sections', [])),
        "total_new": len(new_data.get('sections', []))
    }
    
    # compare the metadata between the new one and old one
    old_meta = old_data.get('metadata', {})
    new_meta = new_data.get('metadata', {})
    
    for key in set(list(old_meta.keys()) + list(new_meta.keys())):
        old_val = old_meta.get(key)
        new_val = new_meta.get(key)
        if old_val != new_val:
            comparison['metadata_changes'][key] = {
                'old': old_val,
                'new': new_val
            }
    
    # then compare and count them adter that add a notify
    old_sections = {s.get('section'): s for s in old_data.get('sections', [])}
    new_sections = {s.get('section'): s for s in new_data.get('sections', [])}
    
    comparison['sections_added'] = len(set(new_sections.keys()) - set(old_sections.keys()))
    comparison['sections_removed'] = len(set(old_sections.keys()) - set(new_sections.keys()))
    
    for section_num in set(old_sections.keys()) & set(new_sections.keys()):
        old_sec = old_sections[section_num]
        new_sec = new_sections[section_num]
        if old_sec.get('text') != new_sec.get('text') or old_sec.get('title') != new_sec.get('title'):
            comparison['sections_modified'] += 1
    
    return comparison