QA_PROMPT = """
You are a Malaysian legal assistant.
Answer the question based ONLY on the provided document content.
Cite section numbers where possible.
Answer in plain English.

Question:
{question}

Document Sections:
{context}

Answer:
"""

SUMMARY_PROMPT = """
Summarize the following legal document in plain English.
Highlight:
- Purpose
- Key obligations
- Penalties or consequences
- Important sections

Document:
{context}

Summary:
"""

CLAUSE_PROMPT = """
Identify the most important clauses or sections in this legal document.
For each clause:
- State the section
- Explain why it is important

Document:
{context}

Important Clauses:
"""
