import re
from pypdf import PdfReader
from docx import Document

def extract_text_from_pdf(file):
    reader = PdfReader(file)
    text = ""
    for page_num, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text()
        if page_text:
            text += f"\n--- Page {page_num} ---\n{page_text}"
    return text


def extract_text_from_docx(file):
    doc = Document(file)
    return "\n".join(p.text for p in doc.paragraphs)


def split_into_sections(text, act_name="Uploaded Document"):
    pattern = r"(Section\s+\d+[A-Za-z]?\s*(?:\([^)]+\))?\s*.*)"
    parts = re.split(pattern, text)

    sections = []
    current = None

    for part in parts:
        if part.strip().startswith("Section"):
            if current:
                sections.append(current)

            match = re.match(r"Section\s+(\d+[A-Za-z]?)\s*(.*)", part.strip())
            current = {
                "act": act_name,
                "section": match.group(1) if match else "",
                "title": match.group(2).strip() if match else "",
                "text": ""
            }
        else:
            if current:
                current["text"] += part.strip() + " "

    if current:
        sections.append(current)
    if not sections:
        chunk_size = 1500
        for i in range(0, len(text), chunk_size):
            sections.append({
                "act": act_name,
                "section": f"Chunk {i//chunk_size + 1}",
                "title": "",
                "text": text[i:i+chunk_size]
            })

    return sections
