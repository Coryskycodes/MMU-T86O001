from openai import OpenAI
from .prompts import QA_PROMPT, SUMMARY_PROMPT, CLAUSE_PROMPT

MAX_CHARS = 6000


def create_client(api_key):
    return OpenAI(api_key=api_key)


def build_context(sections):
    context = ""
    for sec in sections:
        context += f"{sec['act']} - Section {sec['section']} {sec['title']}:\n{sec['text']}\n\n"
        if len(context) > MAX_CHARS:
            break
    return context


def ask_uploaded_doc(question, sections, api_key):
    client = create_client(api_key)
    context = build_context(sections)

    prompt = QA_PROMPT.format(question=question, context=context)

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content


def summarize_uploaded_doc(sections, api_key):
    client = create_client(api_key)
    context = build_context(sections)

    prompt = SUMMARY_PROMPT.format(context=context)

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content


def extract_key_clauses(sections, api_key):
    client = create_client(api_key)
    context = build_context(sections)

    prompt = CLAUSE_PROMPT.format(context=context)

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content
