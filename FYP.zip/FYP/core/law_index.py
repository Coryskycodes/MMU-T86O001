import os
import json
import re
from collections import defaultdict

# Import again like the generator but only the law folder
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LAWS_FOLDER

LAW_FOLDER = LAWS_FOLDER

STOPWORDS = {
    "the", "and", "of", "to", "in", "a", "is", "shall", "may", "any"
}

def extract_keywords(text):
    words = re.findall(r"[A-Za-z]{3,}", text.lower())
    return list(set(w for w in words if w not in STOPWORDS))

def build_law_index():
    index = defaultdict(list)

    for filename in os.listdir(LAW_FOLDER):
        if not filename.endswith(".json"):
            continue

        path = os.path.join(LAW_FOLDER, filename)

        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            
            # trying to see if this one works
            if isinstance(data, dict) and 'sections' in data:
                act_name = data['metadata']['file_key']
                sections = data['sections']
            else:
                # backup if the new format cannot somehow
                act_name = filename.replace(".json", "")
                sections = data

        for sec in sections:
            combined_text = f"{sec.get('title','')} {sec.get('text','')}"
            index[act_name].append({
                "act": act_name,
                "section": sec.get("section"),
                "title": sec.get("title"),
                "text": sec.get("text"),
                "keywords": extract_keywords(combined_text)
            })

    return index
