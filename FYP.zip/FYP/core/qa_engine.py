import json
import os
from openai import OpenAI
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LAWS_FOLDER
from .law_index import build_law_index
from .law_selector import select_relevant_sections

LAW_FOLDER = LAWS_FOLDER

# load em laws up
laws = {}
for filename in os.listdir(LAW_FOLDER):
    if filename.endswith(".json"):
        path = os.path.join(LAW_FOLDER, filename)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            
            # this one new format
            if isinstance(data, dict) and 'sections' in data:
                file_key = data['metadata']['file_key']
                laws[file_key] = data['sections']
            else:
                # this one is backup in case why i don't make it organized at 1st i dunno
                # answer is lazy
                laws[filename.replace(".json", "")] = data

# create the indxe after the other model import
print("Building law index...")
LAW_INDEX = build_law_index()
print(f"Index built for {len(LAW_INDEX)} Acts")

# we like space bars but also _
ACT_NAME_MAPPING = {
    "Contracts Act 1950": "contracts_act_1950",
    "Employment Act 1955": "employment_act_1955",
    "Companies Act 2016": "companies_act_2016",
    "National Land Code 1965": "national_land_code_1965",
    "Income Tax Act 1967": "income_tax_act_1967",
    "Civil Law Act 1956": "civil_law_act_1956",
    "Intellectual Property Corporation of Malaysia Act 2002": "ip_act_2002",
    "INTELLECTUAL PROPERTY CORPORATION OF MALAYSIA ACT 2002": "ip_act_2002",
}


REVERSE_ACT_MAPPING = {v: k for k, v in ACT_NAME_MAPPING.items()}

# this over here to make sure no token overflow
# open ai is stingy
def estimate_tokens(text):
    return len(text) // 4

MAX_TOKENS_PER_BATCH = 1500


def create_openai_client(api_key):
    return OpenAI(api_key=api_key)

def summarize_batch(question, batch, api_key):
    client = create_openai_client(api_key)
    context_text = ""
    current_tokens = 0
    for sec in batch:
        sec_tokens = estimate_tokens(sec['text'])
        if current_tokens + sec_tokens > MAX_TOKENS_PER_BATCH:
            break
        context_text += f"{sec['act']} - Section {sec['section']} ({sec['title']}): {sec['text']}\n\n"
        current_tokens += sec_tokens

    prompt = f"""
You are a helpful Malaysian legal assistant.
Answer the question in plain English based ONLY on the provided law sections.
Cite the section numbers and Acts when relevant.

Question: {question}

Relevant sections:
{context_text}

Answer:
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content

def summarize_with_batches(question, selected_sections, api_key, batch_size=3):
    batches = [selected_sections[i:i+batch_size] for i in range(0, len(selected_sections), batch_size)]
    batch_summaries = []
    for batch in batches:
        summary = summarize_batch(question, batch, api_key)
        batch_summaries.append(summary)

    final_prompt = f"""
You are a helpful Malaysian legal assistant.
Combine the following batch summaries to answer the question in plain English.
Cite relevant Acts and sections if applicable.

Question: {question}

Batch summaries:
{chr(10).join(batch_summaries)}

Answer:
"""
    client = create_openai_client(api_key)
    final_response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": final_prompt}],
        temperature=0
    )
    return final_response.choices[0].message.content

# search it split it rank it
# add fall back bc open ai sometime got prob
def search_law(question, law_sections, top_k=5):
    question_words = question.lower().split()
    results = []

    for sec in law_sections:
        text_lower = sec['text'].lower()
        match_count = sum(word in text_lower for word in question_words)
        if match_count > 0:
            results.append((match_count, sec))

    results.sort(reverse=True, key=lambda x: x[0])
    return [sec for _, sec in results[:top_k]]

def select_relevant_acts(question, available_acts, api_key):
    client = create_openai_client(api_key)
    
   
    friendly_names = [REVERSE_ACT_MAPPING.get(act, act) for act in available_acts]
    acts_list = "\n".join([f"- {name}" for name in friendly_names])
    
    prompt = f"""You are a Malaysian legal expert. Given a legal question, identify which Malaysian Acts are most relevant.

Available Acts:
{acts_list}

Question: {question}

Return ONLY the names of the 2-3 most relevant Acts, one per line, exactly as they appear above.
If unsure, default to "Contracts Act 1950"."""

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    
    selected_friendly = response.choices[0].message.content.strip().split('\n')
    selected_friendly = [act.strip('- ').strip() for act in selected_friendly if act.strip()]
    
    # Convert friendly names back to file names
    selected_file_names = []
    for friendly in selected_friendly:
        file_name = ACT_NAME_MAPPING.get(friendly, None)
        if file_name and file_name in available_acts:
            selected_file_names.append(file_name)
    if not selected_file_names:
        selected_file_names = ["contracts_act_1950"]
    
    return selected_file_names

# tell it to answer with chain of thought
def answer_with_chain_of_thought(question, selected_sections, references, api_key):
    """
    Generate answer with visible reasoning process
    """
    client = create_openai_client(api_key)
    
    # this one here to help build the context needed i think
    context_text = ""
    for sec in selected_sections:
        context_text += f"{sec['act']} - Section {sec['section']} ({sec['title']}): {sec['text'][:500]}...\n\n"
    
    prompt = f"""You are a helpful Malaysian legal assistant.

Answer the question using the provided law sections. Show your reasoning in three parts:

1. ANALYSIS: Briefly explain which sections are relevant and why
2. REASONING: Explain the legal logic and how the sections apply
3. ANSWER: Provide a clear, practical answer in plain English

Question: {question}

Relevant Law Sections:
{context_text}

Provide your response in the following format:
**ANALYSIS:**
[Your analysis here]

**REASONING:**
[Your reasoning here]

**ANSWER:**
[Your final answer here]

Remember to cite specific sections (e.g., "According to Section 10 of the Contracts Act 1950...").
"""

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful Malaysian legal assistant who thinks step-by-step."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=1000
    )
    
    return response.choices[0].message.content

# this one for fancy stuff
# generate the starter and follow up qna 
# tea break come back add prompt rmbr for the suggestion
def generate_starter_questions(laws, api_key, n=3):
    client = create_openai_client(api_key)
    context_text = ""
    for law_name, sections in list(laws.items())[:5]:  # Use first 5 acts
        context_text += f"{law_name}: {sections[0]['title']}\n"

    prompt = f"""You are a Malaysian legal assistant.
Based only on the following laws, suggest {n} interesting questions a user might ask.
Provide only the questions, one per line.

Context:
{context_text}
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    questions_text = response.choices[0].message.content.strip()
    questions = [q.strip("-1234567890. ") for q in questions_text.splitlines() if q.strip()]
    return questions[:n]

def generate_followup_questions(answer, api_key, n=3):
    client = create_openai_client(api_key)
    prompt = f"""You are a Malaysian legal assistant.
Given the following answer, suggest {n} possible follow-up questions a user might ask.
List them 1-{n} only, one per line.

Answer:
{answer}
"""
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    questions_text = response.choices[0].message.content.strip()
    questions = [q.strip("-1234567890. ") for q in questions_text.splitlines() if q.strip()]
    return questions[:n]

# create the function for app 
def get_answer_for_app(user_question, api_key):
    """
    Enhanced Q&A with hybrid approach:
    1. Try smart indexing first
    2. Fall back to simple search if no matches
    """
    
    # select the act
    # keyword search to find the sec
    # if cannot the do simple one
    #gen ans with cot
    # add follow ques
    available_acts = list(LAW_INDEX.keys())
    print(f"DEBUG: Available acts: {available_acts}")
    
    selected_acts = select_relevant_acts(user_question, available_acts, api_key)
    print(f"DEBUG: Selected acts: {selected_acts}")
    
    selected_sections, references = select_relevant_sections(
        question=user_question,
        law_index=LAW_INDEX,
        selected_acts=selected_acts,
        top_k=10
    )
    print(f"DEBUG: Keyword matching found {len(selected_sections)} sections")
    
    if not selected_sections:
        print(f"⚠️ Keyword matching found nothing. Falling back to simple search...")
        for act_name in selected_acts:
            print(f"DEBUG: Trying simple search in {act_name}")
            print(f"DEBUG: act_name in laws? {act_name in laws}")
            if act_name in laws:
                law_sections = laws[act_name]
                print(f"DEBUG: Found {len(law_sections)} sections in {act_name}")
                simple_results = search_law(user_question, law_sections, top_k=10)
                print(f"DEBUG: Simple search found {len(simple_results)} results")
                if simple_results:
                    selected_sections = simple_results
                    references = [
                        {
                            "act": sec.get("act", act_name),
                            "section": sec.get("section", "N/A"),
                            "matched_keywords": ["(simple search)"]
                        }
                        for sec in simple_results
                    ]
                    print(f"DEBUG: Using simple search results")
                    break
    
    if not selected_sections:
        print(f"DEBUG: FINAL - No sections found at all!")
        return {
            "answer": "No matching sections found in the loaded Malaysian laws.",
            "references": [],
            "selected_acts": selected_acts,
            "followups": []
        }
    
    print(f"DEBUG: Proceeding with {len(selected_sections)} sections")
    
    answer = answer_with_chain_of_thought(
        user_question,
        selected_sections,
        references,
        api_key
    )
    followups = generate_followup_questions(answer, api_key)
    
    return {
        "answer": answer,
        "references": references,
        "selected_acts": selected_acts,
        "selected_sections": selected_sections,
        "followups": followups
    }