# heh reeeee
import re

def score_section(question_words, section_keywords):
    return sum(1 for w in question_words if w in section_keywords)

def select_relevant_sections(
    question,
    law_index,
    selected_acts,
    top_k=5
):
    question_words = set(
        re.findall(r"[A-Za-z]{3,}", question.lower())
    )

    scored = []

    for act in selected_acts:
        for sec in law_index.get(act, []):
            score = score_section(question_words, sec["keywords"])
            if score > 0:
                scored.append((score, sec))

    scored.sort(reverse=True, key=lambda x: x[0])
    selected = scored[:top_k]

    sections = [s for _, s in selected]

    references = [
        {
            "act": s["act"],
            "section": s["section"],
            "matched_keywords": list(
                question_words.intersection(s["keywords"])
            )
        }
        for s in sections
    ]

    return sections, references