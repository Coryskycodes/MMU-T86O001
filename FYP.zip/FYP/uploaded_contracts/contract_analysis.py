from openai import OpenAI

MAX_CHARS = 6000

def create_client(api_key):
    return OpenAI(api_key=api_key)

def build_context(clauses):
    context = ""
    for clause in clauses:
        context += f"Clause {clause.get('clause_number', '')} {clause.get('title','')}:\n{clause.get('text','')}\n\n"
        if len(context) > MAX_CHARS:
            break
    return context

#cot portion adde
# then need to validate the cot
def analyze_risks(clauses, api_key):
    client = create_client(api_key)
    context = build_context(clauses)
    
    prompt = f"""You are a Malaysian legal assistant analyzing contract risks.

Provide your analysis in the following format:

**INITIAL REVIEW:**
[Summarize the contract type and key clauses identified]

**RISK ASSESSMENT:**
[Identify potential risks, unfair terms, and problematic clauses]
[Explain WHY each item is risky under Malaysian law]

**COMPLIANCE CHECK:**
[Check against Malaysian legal requirements]
[Note any missing standard clauses required by law]

**RECOMMENDATIONS:**
[Provide specific, actionable recommendations to mitigate risks]

Contract Clauses:
{context}

Provide detailed analysis with clear reasoning.
"""
    
    resp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a Malaysian legal expert who provides detailed risk analysis with clear reasoning."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=1500
    )
    return resp.choices[0].message.content

def validate_contract(clauses, api_key):
    """
    Validate contract with chain-of-thought reasoning
    """
    client = create_client(api_key)
    context = build_context(clauses)
    
    prompt = f"""You are a Malaysian legal assistant validating a contract.

Provide your validation in the following format:

**STRUCTURAL REVIEW:**
[Check if contract has proper structure: parties, consideration, terms, signatures]
[Note any structural deficiencies]

**LEGAL COMPLIANCE:**
[Verify compliance with Malaysian Contracts Act 1950 and other relevant laws]
[Cite specific sections where applicable]

**COMPLETENESS CHECK:**
[Identify missing essential clauses]
[List any ambiguous or unclear terms]

**VALIDATION SUMMARY:**
[Overall assessment: Valid / Valid with Issues / Invalid]
[Key findings and required corrections]

Contract Clauses:
{context}

Provide thorough validation with legal reasoning.
"""
    
    resp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a Malaysian legal expert who validates contracts with detailed reasoning."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=1500
    )
    return resp.choices[0].message.content

def extract_obligations_rights(clauses, api_key):
    """
    Extract obligations and rights with chain-of-thought reasoning
    """
    client = create_client(api_key)
    context = build_context(clauses)
    
    prompt = f"""You are a Malaysian legal assistant extracting key contract elements.

Provide your extraction in the following format:

**ANALYSIS APPROACH:**
[Explain how you're identifying obligations, rights, and penalties]
[Note the legal framework being applied]

**PARTY A OBLIGATIONS:**
[List specific obligations with clause references]
[Explain the nature and extent of each obligation]

**PARTY B OBLIGATIONS:**
[List specific obligations with clause references]
[Explain the nature and extent of each obligation]

**PARTY A RIGHTS:**
[List rights and entitlements with clause references]

**PARTY B RIGHTS:**
[List rights and entitlements with clause references]

**PENALTIES & REMEDIES:**
[List penalties, damages, and remedies specified]
[Explain conditions and amounts]

**KEY OBSERVATIONS:**
[Note any imbalances, unusual terms, or important conditions]

Contract Clauses:
{context}

Provide comprehensive extraction with clear reasoning.
"""
    
    resp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a Malaysian legal expert who extracts contract elements with detailed analysis."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=1500
    )
    return resp.choices[0].message.content

#break and later on come back continue with cot for con query
def query_contract(question, clauses, api_key):
    """
    Answer questions about contract with chain-of-thought reasoning
    """
    client = create_client(api_key)
    context = build_context(clauses)
    
    prompt = f"""You are a Malaysian legal assistant analyzing a contract.

Provide your answer in the following format:

**QUESTION ANALYSIS:**
[Understand what the question is asking]
[Identify which clauses are most relevant]

**RELEVANT CLAUSES:**
[Quote or reference the specific clauses that address the question]

**LEGAL INTERPRETATION:**
[Explain what these clauses mean in legal terms]
[Reference Malaysian law if applicable]

**ANSWER:**
[Provide a clear, direct answer to the question]
[Include any important caveats or conditions]

Question: {question}

Contract Content:
{context}

Provide detailed analysis with clear reasoning.
"""
    
    resp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a Malaysian legal expert who answers contract questions with thorough analysis."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=1000
    )
    return resp.choices[0].message.content
