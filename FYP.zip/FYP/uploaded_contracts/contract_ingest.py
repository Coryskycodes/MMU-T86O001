import re
from pypdf import PdfReader
from docx import Document

#extract the pdf/doc first
# then split it and make sure chunk them to around 1500 for open api
def extract_text_from_pdf(file):
    reader = PdfReader(file)
    text = ""
    for page_num, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text()
        if page_text:
            text += f"\n--- Page {page_num} ---\n{page_text}"
    return text

def extract_text_from_docx(file):
    doc = Document(file)
    return "\n".join(p.text for p in doc.paragraphs)

def split_into_clauses(text, contract_name="Uploaded Contract"):
    pattern = r"(\d+\..+?)(?=\n\d+\.|\Z)"  
    matches = re.findall(pattern, text, flags=re.DOTALL)

    clauses = []
    if matches:
        for idx, clause_text in enumerate(matches, start=1):
            lines = clause_text.strip().split("\n", 1)
            title = lines[0].strip() if lines else ""
            body = lines[1].strip() if len(lines) > 1 else ""
            clauses.append({
                "clause_number": str(idx),
                "title": title,
                "text": body
            })
    else:
        chunk_size = 1500
        for i in range(0, len(text), chunk_size):
            clauses.append({
                "clause_number": f"Chunk {i//chunk_size + 1}",
                "title": "",
                "text": text[i:i+chunk_size]
            })

    return clauses
