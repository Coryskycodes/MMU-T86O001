from .generator import generate_contract_for_app
