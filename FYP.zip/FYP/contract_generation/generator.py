import os
from fpdf import FPDF
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from openai import OpenAI
import json

# Import the config for paths
# Make sure it is dynamic so later can use files later uploaded
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import LAWS_FOLDER, CONTRACTS_OUTPUT_FOLDER


# Folders variable defining
# make easy for use later

LAW_FOLDER = LAWS_FOLDER
OUTPUT_FOLDER = CONTRACTS_OUTPUT_FOLDER


# Load laws v4
# reorganized for new json format

laws = {}
for filename in os.listdir(LAW_FOLDER):
    if filename.endswith(".json"):
        path = os.path.join(LAW_FOLDER, filename)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            
            # Handle new format with metadata
            if isinstance(data, dict) and 'sections' in data:
                file_key = data['metadata']['file_key']
                laws[file_key] = data['sections']
            else:
                # Fallback for old format (just in case)
                law_name = filename.replace(".json", "")
                laws[law_name] = data


# contract types and law map
# updated for new file org

contract_law_map = {
    "Employment Contract": ["employment_act_1955", "contracts_act_1950"],
    "Tenancy Agreement": ["national_land_code_1965", "contracts_act_1950"],
    "Non-Disclosure Agreement (NDA)": ["contracts_act_1950", "companies_act_2016"],
    "Intellectual Property Agreement": ["ip_act_2002", "contracts_act_1950"],
    "General Contract under Contracts Act 1950": ["contracts_act_1950"]
}

# names for display
# i dont like underscore
FRIENDLY_LAW_NAMES = {
    "employment_act_1955": "Employment Act 1955",
    "contracts_act_1950": "Contracts Act 1950",
    "national_land_code_1965": "National Land Code 1965",
    "companies_act_2016": "Companies Act 2016",
    "ip_act_2002": "Intellectual Property Corporation of Malaysia Act 2002",
    "civil_law_act_1956": "Civil Law Act 1956",
    "income_tax_act_1967": "Income Tax Act 1967"
}


# OpenAI client factory
# openai getting the key
# i ain't paying for other people
# if lecturer then i probably did send you the api key for access :)
def create_openai_client(api_key):
    return OpenAI(api_key=api_key)


#export le pdfs
# make sure that the pdf text do not overflow
# added the multi cell so the text wraps, really they can't just use the word text wrab

def save_contract_to_pdf(contract_text, contract_type, output_folder=OUTPUT_FOLDER):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.set_font("Arial", "B", 16)
    pdf.multi_cell(0, 10, f"{contract_type}\n", align='C')
    pdf.ln(5)
    pdf.set_font("Arial", size=12)
    pdf.multi_cell(0, 8, contract_text)

    filename = f"{contract_type.replace(' ', '_')}.pdf"
    path = os.path.join(output_folder, filename)
    pdf.output(path)
    return path

# this is for exporting the contract in word, instead of pdf this time
def save_contract_to_word(contract_text, contract_type, output_folder=OUTPUT_FOLDER):
    """
    Export contract to Word (.docx) format
    """
    doc = Document()
    
    # brand you document
    title = doc.add_heading(contract_type, 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    doc.add_paragraph()
    
    # Process the contract text
    # make sure them are formatted
    lines = contract_text.split('\n')
    
    for line in lines:
        line = line.strip()
        if not line:
            doc.add_paragraph()  # Empty line
            continue
        
        # Check if it is a head
        if line and (line[0].isdigit() or (line.isupper() and len(line) > 3)):
            # you become heading
            para = doc.add_heading(line, level=2)
        else:
            # you a normie
            para = doc.add_paragraph(line)
            para_format = para.paragraph_format
            para_format.line_spacing = 1.15
    
    # Save it don't lose it
    filename = f"{contract_type.replace(' ', '_')}.docx"
    path = os.path.join(output_folder, filename)
    doc.save(path)
    return path


# Generate contract with chain thinking
def generate_contract_for_app(contract_type, user_input, pdf=False, api_key=None):
    client = create_openai_client(api_key)
    
    # prepare it for the ai to have the legal context and understand
    law_texts = ""
    relevant_law_files = contract_law_map.get(contract_type, [])
    law_references = []
    
    for law_file in relevant_law_files:
        if law_file in laws:
            friendly_name = FRIENDLY_LAW_NAMES.get(law_file, law_file)
            sections = laws[law_file]
            
            # get more sections for better context
            for sec in sections[:5]:
                text_snippet = sec.get('text', '')[:600]
                section_num = sec.get('section', 'N/A')
                section_title = sec.get('title', '')
                
                law_texts += f"{friendly_name} - Section {section_num} ({section_title}):\n{text_snippet}\n\n"
                
                # Track references for output later
                law_references.append({
                    "act": friendly_name,
                    "section": section_num,
                    "title": section_title
                })

    prompt = f"""You are a Malaysian legal expert drafting contracts.

Create a {contract_type} based on Malaysian law with the following structure:

1. LEGAL ANALYSIS:
   - Identify which laws and sections are most relevant
   - Explain the key legal requirements for this contract type

2. DRAFTING REASONING:
   - Explain your approach to drafting each major clause
   - Note which law sections inspire which clauses

3. CONTRACT:
   - The complete, professionally formatted contract
   - Cite specific law sections in [brackets] after relevant clauses

User Requirements:
{user_input}

Relevant Malaysian Law Excerpts:
{law_texts}

Provide your response in the following format:

**LEGAL ANALYSIS:**
[Your analysis of applicable laws]

**DRAFTING REASONING:**
[Explain your drafting approach and which sections inspired which clauses]

**CONTRACT:**
[The complete contract with section citations]

Remember to make the contract practical, legally sound, and cite specific sections.
"""

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful Malaysian legal expert who drafts contracts with clear reasoning."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.3,
        max_tokens=2000
    )
    
    full_response = response.choices[0].message.content
    
    # Extract just the contract portion for PDF no need analyze
    contract_only = full_response
    if "**CONTRACT:**" in full_response:
        contract_only = full_response.split("**CONTRACT:**")[1].strip()
    
    pdf_path = None
    word_path = None
    
    if pdf:
        pdf_path = save_contract_to_pdf(contract_only, contract_type)
        word_path = save_contract_to_word(contract_only, contract_type)
    
    # give the response with the reasoning and source
    return {
        "full_response": full_response,
        "contract_only": contract_only,
        "pdf_path": pdf_path,
        "word_path": word_path,
        "law_references": law_references,
        "relevant_acts": [FRIENDLY_LAW_NAMES.get(f, f) for f in relevant_law_files]
    }
